import React from 'react';
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonInput, IonCard, IonButton } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';

const Tab5: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Tab 5</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        {/* <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Tela de login</IonTitle>
          </IonToolbar>
        </IonHeader> */}

        <IonCard>
            <IonInput placeholder='Digite o seu login'/>
            <IonInput placeholder='Digite o seu login' type='password' />
        </IonCard>
        

        <ExploreContainer name="Tab 5 page" />
      </IonContent>
      <IonButton routerLink='/tab1' color='danger'>
        Logar
      </IonButton>
    </IonPage>
  );
};

export default Tab5;
