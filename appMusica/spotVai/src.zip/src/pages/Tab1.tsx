import React from 'react';
import { IonContent, IonHeader, IonPage, IonText, IonTitle, IonToolbar, IonItem, IonAvatar, IonImg, IonLabel, IonList, IonButton } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Tab1.css';

const Tab1: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Sua lista de reprodução</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
         <IonTitle className='ion-padding' /*size='large'*/>Bem-Vindo, Rafael</IonTitle> 
        <IonContent className='ion-padding'>O que deseja ouvir hoje?</IonContent>
        
        {/* <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Tab 1</IonTitle>
          </IonToolbar>
        </IonHeader> */}
      </IonContent>

      <IonList>

      <IonItem>
        <IonAvatar slot='start'>
          <IonImg/>
        </IonAvatar>
        <IonLabel>
          Tribo de Periferia
        </IonLabel>
      </IonItem>

      <IonItem>
        <IonAvatar slot='start'>
          <IonImg/>
        </IonAvatar>
        <IonLabel>
          Guns N Roses
        </IonLabel>
      </IonItem>

      <IonItem>
        <IonAvatar slot='start'>
          <IonImg/>
        </IonAvatar>
        <IonLabel>
          Nirvana
        </IonLabel>
      </IonItem>

      <IonItem>
        <IonAvatar slot='start'>
          <IonImg/>
        </IonAvatar>
        <IonLabel>
          Metalica
        </IonLabel>
      </IonItem>

      <IonItem>
        <IonAvatar slot='start'>
          <IonImg/>
        </IonAvatar>
        <IonLabel>
          Pedra Letícia
        </IonLabel>
      </IonItem>

      </IonList>

      <IonButton routerLink='/tab5'>
        LOGOUT
      </IonButton>

      

    </IonPage>
  );
};

export default Tab1;
