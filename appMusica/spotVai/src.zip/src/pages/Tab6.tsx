import React from 'react';
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonItem, IonAvatar, IonImg, IonLabel, IonList } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';

const Tab6: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Tab 5</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        {/* <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Tela de login</IonTitle>
          </IonToolbar>
        </IonHeader> */}

        <IonList>
            <IonItem  routerLink='/tab3'>
                <IonAvatar>
                    <IonImg/>
                </IonAvatar>
                <IonLabel>
                    Nome da Música
                </IonLabel>
            </IonItem>
        </IonList>
      </IonContent>
      
    </IonPage>
  );
};

export default Tab6;
