import React from "react";
import { Text } from "react-native";
import styles from '../styles/styles';

export default function Confirmation(){
    return<>
        <Text style={styles.cestaCarnes}>Usuário adicionado com sucesso</Text>
    </>
}